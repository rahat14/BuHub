package com.metacodersbd.myapplication.PdfDownloaderSection;

public class model_For_upload {

    String book_Name  , writer_Name ;


    public model_For_upload() {

    }

    public model_For_upload(String book_Name, String writer_Name) {
        this.book_Name = book_Name;
        this.writer_Name = writer_Name;
    }
}
