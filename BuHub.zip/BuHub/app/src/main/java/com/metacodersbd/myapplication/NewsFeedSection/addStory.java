package com.metacodersbd.myapplication.NewsFeedSection;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import id.zelory.compressor.Compressor;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.metacodersbd.myapplication.R;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import static java.lang.System.currentTimeMillis;


public class addStory extends AppCompatActivity {

    EditText title,description ;
    Button  upld_btn ;
    ImageView image ;
    String mTitle = "  " , mDescription = "  ";

    Uri download_uri  = null ;
    String User_id ;
private DatabaseReference UserRef  ;
private  StorageReference UserPostRef ;
private FirebaseAuth mauth ;
    private boolean isChanged = false;

    private Bitmap compressedImageFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_story);
        mauth = FirebaseAuth.getInstance() ;
        User_id = mauth.getCurrentUser().getUid() ;
        UserRef = FirebaseDatabase.getInstance().getReference("NewsFeed");
        UserPostRef = FirebaseStorage.getInstance().getReference("newsFeed_pic") ;






        //setting up viewes ;
         title = findViewById(R.id.input_title);
         description = findViewById(R.id.input_Desc_story) ;
         upld_btn = findViewById(R.id.add_stroy_uploadBtn);

         //setting up listenre

        upld_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




            }
        });


       image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

                    if(ContextCompat.checkSelfPermission(addStory.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){

                        ActivityCompat.requestPermissions(addStory.this,
                                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                    } else {

                        BringImagePicker();

                    }

                } else {

                    BringImagePicker();

                }

            }

        });
    }


    private void BringImagePicker() {

        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .setAspectRatio(1, 1)
                .start(addStory.this);

    }

    private void  saveStory() {
        mTitle = title.getText().toString() ;
        mDescription = description.getText().toString();

        if(!TextUtils.isEmpty(mTitle) || !TextUtils.isEmpty(mDescription))
        {
            HashMap userMap = new HashMap();
            userMap.put("title", mTitle);
            userMap.put("desc", mDescription);
            userMap.put("uid", User_id);

            UserRef.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {

                    if(task.isSuccessful()){

                        Toast.makeText(addStory.this, " Updated!", Toast.LENGTH_LONG).show();
                    }

                    else{


                        String message = task.getException().getMessage();
                        Toast.makeText(addStory.this, "Error: " + message, Toast.LENGTH_SHORT).show();
                    }

                }
            });

            sendUserToNewsFeedActivity();
        }

        else {
            Toast.makeText(getApplicationContext()  , "Please Fill All The Place Properly", Toast.LENGTH_SHORT).show();

        }

        }

        public void  sendUserToNewsFeedActivity(){

            Intent mainIntent = new Intent(getApplicationContext(), newsFeed.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(mainIntent);
            finish();

        }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                download_uri = result.getUri();
              image.setImageURI(download_uri);


           //     currentUserID = mAuth.getCurrentUser().getUid();

                File newImageFile = new File(download_uri.getPath());
                try {

                    compressedImageFile = new Compressor(addStory.this)
                            .setMaxHeight(125)
                            .setMaxWidth(125)
                            .setQuality(50)
                            .compressToBitmap(newImageFile);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                compressedImageFile.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] thumbData = baos.toByteArray();

                StorageReference image_path = UserPostRef.child(currentTimeMillis()+User_id + ".jpg"); // adding image file with unique name

                image_path.putBytes(thumbData).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                        Task<Uri> urlTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!urlTask.isSuccessful());
                        Uri uri = urlTask.getResult();

                        Uri downloadUrl;

                        if(uri != null) {

                            downloadUrl = uri;

                        } else {

                            downloadUrl = download_uri;

                        }


                        UserRef.child(currentTimeMillis()+User_id).setValue(downloadUrl.toString())
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if(task.isSuccessful()){



                                        }

                                        else{

                                            String message = task.getException().getMessage();
                                            Toast.makeText(getApplicationContext(), "Error: " + message, Toast.LENGTH_SHORT).show();

                                        }

                                    }
                                });


                    }
                });

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();
                Toast.makeText(getApplicationContext(), "Error: " + error, Toast.LENGTH_SHORT).show();
                sendUserToNewsFeedActivity();

            }
        }

    }




}

