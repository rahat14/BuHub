package com.metacodersbd.myapplication.PdfDownloaderSection;

public class Model {
    String title ;
    String writer ;
    String link ;

    public Model() {
    }

    public String getTitle() {
        return title;
    }



    public void setTitle(String title) {
        this.title = title;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
