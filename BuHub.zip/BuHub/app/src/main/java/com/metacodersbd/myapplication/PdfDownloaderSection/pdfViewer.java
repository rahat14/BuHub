package com.metacodersbd.myapplication.PdfDownloaderSection;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.github.barteksc.pdfviewer.PDFView;
import com.metacodersbd.myapplication.R;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import io.fabric.sdk.android.services.concurrency.AsyncTask;

import static android.view.View.INVISIBLE;

public class pdfViewer extends AppCompatActivity {

    LinearLayout main ;
PDFView pdfView ;
String url ;
ProgressBar bar ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        Toast.makeText(getApplicationContext(), "We Are Trying Hard To Load Data", Toast.LENGTH_LONG).show();

         main =(LinearLayout)findViewById(R.id.layout_spinner);
        bar = (ProgressBar)findViewById(R.id.progressBar_pdfViewer);

        pdfView=(PDFView) findViewById(R.id.pdfView);
        //
        // url = "https://firebasestorage.googleapis.com/v0/b/buhub-a94bc.appspot.com/o/Pdf_CSE%2FAtmel2468%20.pdf?alt=media&token=41c58ade-edc7-48f8-bedd-53dbcb8cf430";

            url = getIntent().getStringExtra("LINK");

        new RetrievePDFStream().execute(url);

    }
    class RetrievePDFStream extends AsyncTask<String,Void,InputStream> {
        @Override
        protected InputStream doInBackground(String... strings) {
            InputStream inputStream = null;

            try {

                URL urlx = new URL(strings[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) urlx.openConnection();
                if (urlConnection.getResponseCode() == 200) {
                    inputStream = new BufferedInputStream(urlConnection.getInputStream());

                }
            } catch (IOException e) {
                Toast.makeText(getApplicationContext() , "EROR:"+e ,Toast.LENGTH_SHORT).show();

                return null;
            }
            return inputStream;

        }

        @Override
        protected void onPostExecute(InputStream inputStream) {
            bar.setVisibility(INVISIBLE);
            main.setVisibility(LinearLayout.GONE);

           pdfView.fromStream(inputStream).load();

        }
    }
    }
